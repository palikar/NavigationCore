package edu.kit.informatik.Exceptions;

/**
 *
 * @author s_stanis
 * @version 0.0.42
 */
public class WeigthStrategyDoesNotExist extends Exception {

    /**
     * Basic constructor
     *
     * @param msg The message of this exception
     */
    public WeigthStrategyDoesNotExist(String msg) {
        super(msg);
    }
}
